import { HomePage } from "@/components/homepage";

export default function Page() {
  return (
    <HomePage />
  );
}
